close all; clear all; clc;
num = 20;
% Select the required flags
riskSelectFlag = 1; % 1 for Gaussian chance constraint, 2 for DR Risk Constraint
dynamicsSelectFlag = 2; % 1 for 3D spacecraft, 2 for Double Integrator 

% Set Horizon and load the data
if (dynamicsSelectFlag == 1)
    N = 15; 
    PS = loadProblemSetup3D(N);
elseif (dynamicsSelectFlag == 2)
    N = 7; 
    PS = loadProblemSetupLinearSysyem2(N);
end

% Solve the Covariance Steering with DR Risk Constraints
if(riskSelectFlag == 1)
    [SolverTime,Jstar,Ksol,EXsol,Lsol] = SolveCovarianceSteering(PS, dynamicsSelectFlag);
elseif(riskSelectFlag == 2)    
    [SolverTime,Jstar,Ksol,EXsol,Lsol] = SolveDRCovarianceSteering(PS, dynamicsSelectFlag);
end

% store TFC
u_e2=[];
for i = 1:N
    u_e2(i,:) = Lsol{i}; 
end
for n = N+1:num
    u_e2(n,:) = -PS.K_1;
end
save('u_e2.mat','u_e2');

% Monte-Carlo sampling
for l =1:50000
    e_real(:,1)=randn(2,1)*0.1 + 0.01; 
    for m =1 :num
        e_real(:,m+1) = (PS.A+PS.B*u_e2(m,:))*e_real(:,m) + randn(2,1)*0.1;
    end
        a2(l,:)=e_real(:,2);
        a6(l,:)=e_real(:,5);
        a11(l,:)=e_real(:,11);
%         a6(l,:)=e_real(:,6);
end

 
figure(1)
hold on
V = [-1 -1; -1 1; 1 1;1 -1]*PS.stateCC_offset;
p = Polyhedron(V);
p.plot('color', 'lightblue', 'linewidth', 2, 'linestyle', '--');
plot(a11(:,1),a11(:,2),'.r')
plot(a6(:,1),a6(:,2),'.b')
plot(a2(:,1),a2(:,2),'.k')
axis( [-0.7 0.7 -0.7 0.7] )
set(gca,'LineWidth',2)
set(gca,'fontsize',20,'fontname','Times New Roman');
set(gca, 'LooseInset', [0,0,0,0]);
grid off


% compute probability
t1=0
for i =1:50000
    if PS.alphax'*a2(i,:)'<=PS.betax
         t1=t1+1
    else 
         t1=t1+0
    end
end
t2=0
for i =1:50000
    if PS.alphax'*a6(i,:)'<=PS.betax
         t2=t2+1
    else 
         t2=t2+0
    end
end
t3=0
for i =1:50000
    if PS.alphax'*a11(i,:)'<=PS.betax
         t3=t3+1
    else 
         t3=t3+0
    end
end
t1/50000
t2/50000
t3/50000



