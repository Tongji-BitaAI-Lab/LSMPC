function PS = loadProblemSetupLinearSysyem2(N)
    PS.N = N;
    % Initial condition 
    % A = [1 1;0 1];
    % B = [1;1];
    PS.mu0 = [0.01; 0.01;]; % [0; 0];
    PS.Sigma0 = diag([0.01,0.01]); 
    PS.muw = [0; 0;]; % [0; 0];
    PS.Sigmaw = diag([1,1]); 
    
    % Linear System
    dt = 0.2; 
    PS.dt = dt;
    PS = defineDynamics(PS, dt);
    
    % Probability threshold of x
    PS.Ns = 4;
    PS.alphax = [0  0  1 -1;
                 1 -1  0  0];
    PS.alphax = PS.alphax;         
    PS.stateCC_offset = 0.5; % meters
    PS.betax = PS.stateCC_offset * ones(PS.Ns,1);
    failProbx = 0.1; % 0.0005;
    PS.Deltax = failProbx; % 0.03; % JOINT probability of failure 
    
    % Control Chance Constraints
    PS.Nc = 2;
    PS.alphau = [1  -1];
    PS.umax = 1; % Newtons
    PS.betau = PS.umax * ones(PS.Nc,1);
    failProbu = 0.2;
    PS.Deltau = failProbu; % 0.20; 
    
    % Two sided chance constraint parameter
    PS.beta = 1/size(PS.mu0, 1);
    
    % Initialize with uniform risk allocation
    PS = assignRisk(PS);
    % Objective function  
    Q = blkdiag(1,1);
    R = 0.01;
    [K_1,P] = dlqr(PS.A,PS.B,Q,R);
    PS.K_1 = K_1;
    PS.P = P;
    PS = makeCost(PS, Q, R, P);
    % Make Large Matrices
    PS = makeLargeMatrices(PS);
    % Terminal Condition
    sigma_f = dlyap((PS.A-PS.B*K_1)',1.2*PS.D*PS.Sigmaw*PS.D');
    PS.muf = [0;0];
    PS.Sigmaf = sigma_f; % 0.75*PS.Sigma0; 
    

end

function PS = defineDynamics(PS, dt)
    dt2 = dt*dt;
    PS.A = [1 1;0 1];
    PS.B = [1;1];
    PS.nx = size(PS.A, 1);
    PS.nu = size(PS.B, 2);
    PS.nw = PS.nx;
    PS.D  = 0.1*eye(PS.nx);
end

function PS = assignRisk(PS)
    N = PS.N;
    Ns = PS.Ns;
    Nc = PS.Nc;
    Deltax = PS.Deltax;
    Deltau = PS.Deltau;
    deltax = zeros(Ns,N);
    deltau = zeros(Nc,N);
    for k = 1:N
        for j = 1:Ns
            deltax(j,k) = Deltax / (N * Ns);
        end
        for i = 1:Nc
            deltau(i,k) = Deltau / (N * Nc);
        end
    end
    PS.deltax = deltax;
    PS.deltau = deltau;
end

function PS = makeCost(PS,Q0,R0,P0)
    Q = [];
    R = [];
    for i = 1:PS.N
        Q = blkdiag(Q,Q0);
        R = blkdiag(R,R0);
    end
    Q = blkdiag(Q,P0);
    R = blkdiag(R,zeros(PS.nu));
    PS.Q = Q;
    PS.R = R;
end

function PS = makeLargeMatrices(PS)
    nx = PS.nx;
    nu = PS.nu;
    nw = PS.nw;
    N = PS.N;
    A = PS.A;
    B = PS.B;
    D = PS.D;
    
    ScriptA = cell(N+1,N+1);
    ScriptB = cell(N+1,N+1);
    ScriptD = zeros(nx,nx);
    ScriptE = eye(nx,nx);
    ScriptMuw = cell(N+1,1);
    for i = 1:N+1 
     ScriptMuw{i,1}= PS.muw;
    end
    
    
    for i = 1:N+1
        for j = 1:N+1
            ScriptA{i,j}= zeros(nx,nx);
            ScriptB{i,j}= zeros(nx,nu);
        end
    end
    
    for k = 1:N
        ScriptA{k,k} = eye(nx,nx);
        ScriptB{k,k} = -B;
        ScriptD = blkdiag(ScriptD,D) ;
        ScriptE = [ScriptE;zeros(nx,nx)];
    end
    ScriptA{N+1,N+1} = eye(nx,nx);
    ScriptB{N+1,N+1} = -B;
    
    for k = 1:N
    ScriptA{k+1,k} = -A;
    end
    
    PS.ScriptA = cell2mat(ScriptA);
    PS.ScriptB = cell2mat(ScriptB);
    PS.ScriptD = ScriptD;
    PS.ScriptE = ScriptE;
    PS.ScriptMuw = cell2mat(ScriptMuw);
end

