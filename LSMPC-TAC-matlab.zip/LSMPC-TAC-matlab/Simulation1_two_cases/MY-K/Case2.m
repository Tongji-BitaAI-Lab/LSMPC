clear all
close all
load('u_e2.mat'); % load offline 
A = [1 1;0 1];
B = [1;1];
Q = 1*eye(2);
R = 0.01;
[K_1,P] = dlqr(A,B,Q,R);
x0=[-5;-2];
x_real(:,1)=[-5;-2];

x_nom(:,1) =[-5;-2];
num = 10;
sigma_e = cell(num,1);
sigma_e{1} = [0 0;0 0];
sigma_w =[1 0; 0 1]*0.01;
lb = 0.5;
N=7;
t0=cputime;
for i = 1:num
x   = sdpvar(repmat(2,1,N+1),repmat(1,1,N+1));
u   = sdpvar(repmat(1,1,N),repmat(1,1,N));
% aa = sdpvar(2,2);
   objective = 0;
   constraints = [];
   constraints = [constraints, x{1} == x0];
for k = 1:N
    constraints = [constraints, x{k+1} == A*x{k}+ B*u{k}];
end
for k = 1:N
constraints = [constraints,[-10;-5]<=x{k}<=[4;4]];
constraints = [constraints,-1<=u{k}<=1];
end
constraints = [constraints,x{N+1}'*P*x{N+1}<=0.8264];
for k =1:N
   objective   = objective +x{k}'*Q*x{k}+u{k}'*R*u{k}; 
end

    objective = objective+x{N+1}'*P*x{N+1}; 

    solutions = optimize(constraints,objective);  

    u_nom(:,i) = value(u{1});
    %% real system
    x_nom(:,i+1)   =  A*x_nom(:,i) + B*u_nom(:,i);
    %% update
    x0  =x_nom(:,i+1);
end
t1 = cputime-t0;
obj = 0;
for i =1:num
   obj   = obj + x_nom(:,i)'*Q*x_nom(:,i)+ u_nom(:,i)'*R*u_nom(:,i); 
end

   obj  = obj + x_nom(:,end)'*P*x_nom(:,end); 



figure(1)
hold on
V_X = [-10 -4; -10 4; 4 4;4 -4];
p1 = Polyhedron(V_X);
p1.plot('color', 'lightblue', 'linewidth', 2, 'linestyle', '--')
V_ex = [-1 -1; -1 1; 1 1;1 -1]*lb;
p2 = p1-Polyhedron(V_ex);
p2.plot('color', 'gray', 'linewidth', 2, 'linestyle', '--')
x2 = sdpvar (2,1)
plot(x2'*P*x2<=0.8264);
for h = 1:10
V = [-1 -1; -1 1; 1 1;1 -1]*lb+x_nom(:,h)'.*ones(4,2);
p = Polyhedron(V);
p.plot('color', 'lightblue', 'linewidth', 2, 'linestyle', '-');
hold on
end
plot(x_real(1,:),x_real(2,:),'b-o')
plot(x_real(1,end),x_real(2,end),'k-o','MarkerFaceColor','k');
for i = 1:100
    e_real(:,1)=randn(2,1)*0.1+0.01; 
    x_real=x_nom(:,1)+e_real(:,1);
    for h = 1:10
       w(:,h) = randn(2,1)*0.1;
%        e_real(:,h+1)  = (A+B*u_e2(h,:))*e_real(:,h) + w(:,h);
       x_real(:,h+1)  =  A*x_real(:,h) + B*(u_nom(:,h)+u_e2(h,:)*e_real(:,h))+ w(:,h);
       e_real(:,h+1)  = x_real(:,h+1) - x_nom(:,h+1);
    end
    
%     for h = 1:11
%        x_real(:,h)  = x_nom(:,h) + e_real(:,h);
%     end
    plot(x_real(1,1),x_real(2,1),'b-o','MarkerFaceColor','r')
    plot(x_real(1,1:end),x_real(2,1:end),'b-o')
    plot(x_real(1,end),x_real(2,end),'b-o','MarkerFaceColor','g');
    
end
plot(x_nom(1,:),x_nom(2,:),'r-*','linewidth', 2,'linestyle', '--')
legend('1','2','3')
axis( [-11 5 -5 5] ) 
% plot(x_real(1,1),x_real(2,1),'r-o','MarkerFaceColor','r');
set(gca,'LineWidth',2)
set(gca,'fontsize',20,'fontname','Times New Roman');
set(gca, 'LooseInset', [0,0,0,0]);
grid off

figure(2)
hold on
for i = 1:100
    x_real=[-5;-2];
    for h = 1:10
       w(:,h) = randn(2,1)*0.1;
       e_real(:,h+1)  = (A+B*u_e2(h,:))*e_real(:,h) + w(:,h);
       x_real(:,h+1)  =  A*x_real(:,h) + B*(u_nom(:,h)+u_e2(h,:)*e_real(:,h))+ w(:,h);
       ue(i,h) = u_e2(h,:)*e_real(:,h);
       ur(i,h) = u_nom(:,h)+u_e2(h,:)*e_real(:,h);
    end
%     plot(1:10,ue,'b-o')
%     plot(10,ue(end),'o','MarkerFaceColor','g');
    
end
plot(1:10,u_nom(1,:),'r-*');
set(gca,'LineWidth',2)
set(gca,'fontsize',20,'fontname','Times New Roman');


%% ��ʼ��ͼ
figure (3)
%��������Ϊ���ݾ�����ɫ���á���Ƿ�
box_figure = boxplot(ue);
axis( [0 11 -1 1] ) 
%�����߿�
set(box_figure,'Linewidth',1.2);
boxobj = findobj(gca,'Tag','Box');
for i = 1:num
    patch(get(boxobj(i),'XData'),get(boxobj(i),'YData'),'b','FaceAlpha',0.5,...
        'LineWidth',1.1);
end
hold on;
set(gca,'LineWidth',2)
set(gca,'fontsize',20,'fontname','Times New Roman');

