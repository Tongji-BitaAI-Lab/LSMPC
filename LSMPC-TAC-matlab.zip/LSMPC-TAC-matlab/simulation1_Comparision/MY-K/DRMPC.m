clear all
close all
% system martrix
close all; clear all; clc;
% num = 20;
% Select the required flags
riskSelectFlag = 1; % 1 for Gaussian chance constraint, 2 for DR Risk Constraint
dynamicsSelectFlag = 1; % 1 for 3D spacecraft, 2 for Double Integrator 
A = [1 1; 0 1];
B = [1;1];
x0 = [-5;4];
x_real= x0;
% Set Horizon and load the data
N = 7; 
Q = blkdiag(1,1);
R = 0.01;
PS = loadProblemSetupD(N,Q,R);
% cost time
t0 = cputime;

[SolverTime,Jstar,Preu,PS] = SolveCovarianceSteering1(PS,x_real);
t1 = cputime;
time = t1-t0;
    
figure(1)   
for i = 1:100
    w = [1; randn(N*PS.nx,1)];
    u_real = Preu*w;
    Prex = PS.ScriptB * u_real + PS.ScriptC*w;
    Prey = reshape(Prex,PS.nx,PS.N+1);
    x_real = Prey ;
    obj(i,1) = 0;
    for h = 1:7
    obj(i,1)= obj(i,1)+x_real(:,h)'*Q*x_real(:,h)+u_real(h)*R*u_real(h);
    end
    obj(i,1)= obj(i,1)+x_real(:,end)'*Q*x_real(:,end);
    hold on
    plot(x_real(1,:),x_real(2,:),'b-o')
    plot(x_real(1,end),x_real(2,end),'b-o','MarkerFaceColor','g');   
end

% average obj
sum(obj)/100



