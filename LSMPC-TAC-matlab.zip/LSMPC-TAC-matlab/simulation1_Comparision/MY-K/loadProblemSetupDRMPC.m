function PS = loadProblemSetupDRMPC(N,Q,R)
    PS.N = N;    
    PS.mu0 = [10^-20; 10^-20;]; % [0; 0];
    PS.Sigma0 = diag([0,0]); 
    PS.x0 = [-5;-2];
    PS.Muw = [0; 0;]; % [0; 0];
    PS.Sigmaw = [1 -0.1; -0.1 1]; 
    PS.Beta = 1; 
    % Linear System
    dt = 0.2; 
    PS.dt = dt;
    PS = defineDynamics(PS, dt);
    
    % Probability threshold of x
    PS.Ns = 4;
    PS.alphax = [0  0  1 -1;
                 1 -1  0  0];
%     PS.alphax = PS.alphax;         
%     PS.stateCC_offset = 0.5; % meters
    PS.betax = [4;10;4;4];
    failProbx = 0.1; % 0.0005;
    PS.Deltax = failProbx; % 0.03; % JOINT probability of failure 
    
    % Control Chance Constraints
    PS.Nc = 2;
    PS.alphau = [1  -1];
    PS.umax = 2; % Newtons
    PS.betau = PS.umax * ones(PS.Nc,1);
    failProbu = 0.2;
    PS.Deltau = failProbu; % 0.20; 
    
    % Two sided chance constraint parameter
    PS.beta = 1/size(PS.mu0, 1);
    
    % Initialize with uniform risk allocation
    PS = assignRisk(PS);
    % Objective function  
%     Q = blkdiag(1,1);
%     R = 0.01;
    [K_1,P] = dlqr(PS.A,PS.B,Q,R);
    PS.K_1 = K_1;
    PS.P = P;
    PS = makeCost(PS, Q, R, P);
    % Make Large Matrices
%     PS = makeLargeMatrices(PS);
    % Terminal Condition
    sigma_f = dlyap((PS.A-PS.B*K_1)',1.2*PS.D*PS.Sigmaw*PS.D');
    PS.muf = [0;0];
    PS.Sigmaf = sigma_f; % 0.75*PS.Sigma0; 
end

function PS = defineDynamics(PS, dt)
    dt2   = dt*dt;
    PS.A  = [1 1;0 1];
    PS.B  = [1;1];
    PS.nx = size(PS.A, 1);
    PS.nu = size(PS.B, 2);
    PS.nw = PS.nx;
    PS.D  = eye(2);
    PS.C  = 0.1*eye(2);
    PS.E  = zeros(2);
%     PS.x0 = [0;0];
end

function PS = assignRisk(PS)
    N = PS.N;
    Ns = PS.Ns;
    Nc = PS.Nc;
    Deltax = PS.Deltax;
    Deltau = PS.Deltau;
    deltax = zeros(Ns,N);
    deltau = zeros(Nc,N);
    for k = 1:N
        for j = 1:Ns
            deltax(j,k) = Deltax / (N * Ns);
        end
        for i = 1:Nc
            deltau(i,k) = Deltau / (N * Nc);
        end
    end
    PS.deltax = deltax;
    PS.deltau = deltau;
end

function PS = makeCost(PS,Q0,R0,P0)
    Q = [];
    R = [];
    Beta = PS.Beta;
    for i = 1:PS.N
        Q = blkdiag(Q,Q0*Beta^(i-1));
        R = blkdiag(R,R0*Beta^(i-1));
    end
    Q = blkdiag(Q,P0*Beta^(PS.N));
%     R = blkdiag(R,R0);
    PS.Q = Q;
    PS.R = R;
end