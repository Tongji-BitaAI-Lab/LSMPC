function [time,obj,Preu,PS] = SolveCovarianceSteering1(PS, x0)   
    %%% Lower Stage %%%
    N = PS.N;
    nx = PS.nx;
    nu = PS.nu;
    PS = makeLargeMatrices(PS,x0);
    ScriptB=PS.ScriptB ;
    ScriptC=PS.ScriptC ;
    ScriptD=PS.ScriptD ;
    ScriptP=PS.ScriptP;
    ScriptMuw = PS.ScriptMuw;
    a_x = PS.alphax;
    a_u = PS.alphau;
    b_x = PS.betax;
    b_u = PS.betau;
    Ns = PS.Ns;
    Nc = PS.Nc;
    N = PS.N;
    deltax = PS.deltax;
    deltau = PS.deltau;
    nx = PS.nx;
    nu = PS.nu;
    Beta=PS.Beta;
    % Define optimiz ation variables
    K = [];
    for i = 1:N
        K = [K;  sdpvar(nu,i*nx) zeros(nu,(N-i)*nx)];
    end
    U = K*(ScriptD*ScriptC+ScriptP);
    J = trace(U'*(PS.R+ScriptB'*PS.Q*ScriptB)*U*ScriptMuw+2*ScriptC'*PS.Q*ScriptB*U*ScriptMuw+ScriptC'*PS.Q*ScriptC*ScriptMuw);
    Objective = J;
    % Define constraints
    Constraints = [];
%     % Chance Constraints
        Mx = blkdiag(ScriptMuw,0);
%         Beta =sdpvar(1);
     for k = 1:N+1
        X{k}= sdpvar((N+1)*nx,(N+1)*nx);
        Constraints = [Constraints,X{k}>=0];
        Bt=ScriptB((k-1)*nx+1:k*nx,:);
        Ct=ScriptC((k-1)*nx+1:k*nx,:);
%         Constraints = [Constraints,Beta+1/deltax(1,1)*trace(Mx*X{k})<=0];
%         ( Bt*U+Ct)'*( Bt*U+Ct)
        for j = 1:Ns
            P{k,j}= sdpvar((N)*nx+1,(N)*nx+1);
            Constraints = [Constraints,P{k,j}>=0];
            Constraints = [Constraints,X{k}-[P{k,j},(Bt*U+Ct)'*a_x(:,j);a_x(:,j)'*(Bt*U+Ct),-b_x(j)-Beta]>=0];
            Constraints = [Constraints,[P{k,j},(Bt*U+Ct)'*zeros(2);zeros(2)*(Bt*U+Ct),eye(nx)]>=0];
            
        end
     end
%     Constraints = [Constraints,0<=Beta<=1];
%     optimize(Constraints,Beta+1/deltax(1,1)*trace(Mx*X{k}))
%     value(Beta+1/deltax(1,1)*trace(Mx*X{k}))
    

    % Solve the Problem
    sol = optimize(Constraints,Objective)
    
    % Get performance measure values
    time = sol.solvertime;
    obj = value(Objective);
    % Get control values
    Usol =  value(U);
    Ksol =  value(K);
    Preu = Usol;
    
    
end


function PS = makeLargeMatrices(PS,x0)
    nx = PS.nx;
    nu = PS.nu;
    nw = PS.nw;
    N = PS.N;
    A = PS.A;
    B = PS.B;
    D = PS.D;
    C = PS.C;
    E = PS.E;
    Muw = PS.Muw;
    Sigmaw = PS.Sigmaw;
%     x0 = PS.x0;
%   ScriptA = eye(nx);
    ScriptB = zeros(nx,nu*(N));
    ScriptC = [x0,zeros(nx,nx*N)];
    for k = 1:N
        ScriptB = [ScriptB; A*ScriptB(end-nx+1:end,1:(k-1)*nu) B zeros(nx,(N-k)*nu)];
        ScriptC = [ScriptC; A*ScriptC(end-nx+1:end,1:1+(k-1)*nx) C zeros(nx,(N-k)*nx)];
    end
    ScriptD = [];
    ScriptP = [];
    for k = 1:N
        ScriptD = [ScriptD; zeros(nx,nx*(k-1)) D zeros(nx,(N-k+1)*nx)];
        ScriptP = [ScriptP; zeros(nx,1+(k-1)*nx) E zeros(nx,(N-k)*nx)];
    end
    ScriptP(1,1) =  1;
    
    
    PS.ScriptB = ScriptB;
    PS.ScriptC = ScriptC;
    PS.ScriptD = ScriptD;
    PS.ScriptP = ScriptP;
    S_muw = [1; repmat( Muw , N , 1 )];
    PS.S_muw = S_muw;
    PS.ScriptMuw = S_muw*S_muw'+blkdiag(zeros(1),kron(eye(N),Sigmaw));  
end