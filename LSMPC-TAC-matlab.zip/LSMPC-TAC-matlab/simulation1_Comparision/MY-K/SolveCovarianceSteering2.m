function [time,obj,EXsol,Vsol] = SolveCovarianceSteering2(PS)   
    %%% Lower Stage %%%
    x0 = PS.x0;
    N  = PS.N;
    nx = PS.nx;
    nu = PS.nu;
    ScriptA = PS.ScriptA;
    ScriptB = PS.ScriptB;
    ScriptD = PS.ScriptD;
    ScriptE = PS.ScriptE;
    ScriptMuw = PS.ScriptMuw;

    % Define optimiz ation variables
     X = sdpvar((N+1)*nx,1);
     V = [0;sdpvar(N*nu,1)];
     
    % System Dynamics

   
    % Define constraints
    Constraints = [];
    % Boundary condition
    Constraints = [Constraints, X == ScriptA^-1*(ScriptE*x0-+ScriptB*V)];      
     % Chance Constraints
    Constraints = chanceConstraints(Constraints,X,PS);
    % Objective Function
    Jmean = X'*PS.Q*X + V'*PS.R*V;
    Objective =  Jmean;
%     Objective = Jcov;
    % Solve the Problem
    options = sdpsettings('solver','mosek');
    sol = optimize(Constraints,Objective,options)
    
    % Get performance measure values
    time = sol.solvertime;
    obj = value(Objective);
    % Get control values
%     Vsol  = reshape(value(V),nu,N+1);
    Vsol  = value(V);
    EXsol = reshape(value(X),nx,N+1);
    


end

function Constraints = chanceConstraints(Constraints,X,PS)
    a_x = PS.alphax;
    a_u = PS.alphau;
    b_x = PS.betax;
    b_u = PS.betau;
    Ns = PS.Ns;
    Nc = PS.Nc;
    N = PS.N;
    deltax = PS.deltax;
    deltau = PS.deltau;
    nx = PS.nx;
    nu = PS.nu;
    
    % State chance constraints
    for k = 1:N
        Ek = [zeros(nx,k*nx) eye(nx) zeros(nx,(N-k)*nx)];
        for j = 1:Ns
            stateConstraint = a_x(:,j)' * Ek * X <= b_x(j);
            Constraints = [Constraints,stateConstraint];
        end
    end

end