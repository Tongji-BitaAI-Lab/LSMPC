clear all
close all
load('u_e1.mat'); % load offline DACL
N=7;
PS = K_loadProblemSetupLinearSysyem1(N);
A = [1 1;0 1];
B = [1;1];
Q = 1*eye(2);
R = 0.01;
sigma_w =[1 0; 0 1]*0.01;
[K_1,P] = dlqr(A,B,Q,R);
x0=PS.x0;
x_real(:,1)=x0;
e_real(:,1)=[0;0];

num = 10;
sigma_e = cell(num,1);
sigma_e{1} = [0 0;0 0];
for i = 1:20
    sigma_e{i+1} = (A+B*(u_e1(i,:)))*sigma_e{i}*(A+B*(u_e1(i,:)))'+sigma_w;
end
 
sigma_e1 = cell(num,1);
sigma_e1{1} = [0 0;0 0];
for i = 1:20
    sigma_e1{i+1} = (A+B*(-K_1))*sigma_e1{i}*(A+B*(-K_1))'+sigma_w;
end

lb = 0.5;
t0=cputime;
[SolverTime,Jstar,EXsol,Vsol] = SolveCovarianceSteering2(PS);
t1 = cputime;
time = t1-t0;

u_nom = Vsol(2:end);
x_nom   =  EXsol;

figure(1)
hold on
x2 = sdpvar (2,1);
plot(x2'*P*x2<=0.8264);
plot(x_real(1,:),x_real(2,:),'b-o')
plot(x_real(1,end),x_real(2,end),'b-o','MarkerFaceColor','k');
obj = zeros(100,1);
for i = 1:100
    x_real=PS.x0;
    obj(i,1)= x_real(:,1)'*Q*x_real(:,1);
    for h = 1:N
       w(:,h) = randn(2,1)*0.1;
       
       e_real(:,h+1)  = (A+B*u_e1(h,:))*e_real(:,h) + w(:,h);
       
       x_real(:,h+1)  =  A*x_real(:,h) + B*(u_nom(h)+u_e1(h,:)*e_real(:,h))+ w(:,h);
       
       obj(i,1) = obj(i,1)+ x_real(:,h+1)'*Q*x_real(:,h+1)+(u_nom(h)+u_e1(h,:)*e_real(:,h))'*R*(u_nom(h)+u_e1(h,:)*e_real(:,h));
    end
    plot(x_real(1,:),x_real(2,:),'b-o')
    plot(x_real(1,end),x_real(2,end),'b-o','MarkerFaceColor','g');   
end

plot(x_nom(1,:),x_nom(2,:),'r-*')
legend('1','2','3')
axis( [-7 1 -2 4] ) 
plot(x_real(1,1),x_real(2,1),'r-o','MarkerFaceColor','r');
set(gca,'LineWidth',2)
set(gca,'fontsize',20,'fontname','Times New Roman');
set(gca, 'LooseInset', [0,0,0,0]);
grid on
for h = 2:N
error_ellipse( diag(diag(sigma_e{h})),x_nom(:,h),'conf',0.9974);
end
% average obj
sum(obj)/100
