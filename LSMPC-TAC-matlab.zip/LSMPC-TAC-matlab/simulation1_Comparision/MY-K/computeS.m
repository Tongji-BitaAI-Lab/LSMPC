%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file computes the matrix S such that SS^T = SigmaY


function S = computeS(SigmaY)
    [L,D] = ldl(SigmaY);
    S = L * sqrtm(D);
end