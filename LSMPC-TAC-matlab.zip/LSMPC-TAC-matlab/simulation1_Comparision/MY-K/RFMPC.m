clear all
close all
% initial system martrix
A = [1 1;0 1];
B = [1;1];
Q = 1*eye(2);
R = 0.01;
num = 7;
N=7;
% initial condition
x0=[-5;4];
x_real(:,1)=x0;
e_real(:,1)=[0;0];
x_nom(:,1)=x0;
% probability
delta  = 0.1;
deltau = 0.2;
% variance
sigma_w =[1 0; 0 1]*0.01;
% syatem matrix
A = [1 1;0 1];
B = [1;1];
% mpc weight
Q = 1*eye(2);
R = 0.01;
% terminal weight
[K_1,P] = dlqr(A,B,Q,R);
% system num
nx = 2; % Number of states
nu = 1; % Number of inputs
% terminal constraints
sigma_f = dlyap((A-B*K_1)',sigma_w);
% given set
Hbx = [1 0;-1 0; 0 1; 0 -1];
lbx = [4;10;4;5];
px  =  Polyhedron( 'A', Hbx, 'b', lbx);
Hbu =  [1 ;-1];
lbu =  1*ones(2,1);
pu  =  Polyhedron( 'A', Hbu, 'b', lbu);
% system error prograte
sigma_e0 = [0 0;0 0];
sigma_e = cell(num,1);
sigma_e{1} = [0 0;0 0];
for i = 1:30
    sigma_e{i+1} = (A+B*(-K_1))*sigma_e{i}*(A+B*(-K_1))'+sigma_w;
 end

u_e=[];
t0=cputime;
% for i = 1:num
% nominal
    x   = sdpvar(repmat(2,1,N+1),repmat(1,1,N+1));
    u   = sdpvar(repmat(1,1,N),repmat(1,1,N));
% system error
% aa = sdpvar(2,2);
   objective = 0;
   constraints = [];
   constraints = [constraints, x{1} == x0];
%%%%%%%%%%%%%%%%%
   % dynamics
for k = 1:N
    constraints = [constraints, x{k+1} == A*x{k}+ B*u{k}];
end
  % constraint of state and input  
for k = 1:N
% dynamics constraint of state
Hbe = [1 0;-1 0; 0 1; 0 -1];
lbe = [sqrt(sigma_e{k}(1,1)/(delta/4));sqrt(sigma_e{k}(1,1)/(delta/4));sqrt(sigma_e{k}(2,2)/(delta/4));sqrt(sigma_e{k}(2,2)/(delta/4))];
pex =  Polyhedron( 'A', Hbe, 'b', lbe);
prx = px-pex;
Hox = prx.A;  box = prx.b;
constraints = [constraints, Hox * x{k} <= box];
% dynamics constraint of input
Hbu = [1 ;-1 ];
lbu = [sqrt(K_1*sigma_e{k}*K_1'/(deltau/2));sqrt(K_1*sigma_e{k}*K_1'/(deltau/2))];
peu = Polyhedron( 'A', Hbu, 'b', lbu);    
pru = pu-peu;
Hou = pru.A;  bou = pru.b;
% constraints = [constraints, Hou * u{k} <= bou];
end

Hbe = [1 0;-1 0; 0 1; 0 -1];
lbe = [sqrt(sigma_e{N+1}(1,1)/(delta/4));sqrt(sigma_e{N+1}(1,1)/(delta/4));sqrt(sigma_e{N+1}(2,2)/(delta/4));sqrt(sigma_e{N+1}(2,2)/(delta/4))];
pex =  Polyhedron( 'A', Hbe, 'b', lbe);
prx = px-pex;
Hox = prx.A;  box = prx.b;
constraints = [constraints, Hox * x{k} <= box];
% object
for k =1:N
   objective   = objective +x{k}'*Q*x{k}+u{k}'*R*u{k}; 
end

%% terminal constraint

% terminal obj
objective = objective+x{N+1}'*P*x{N+1};         
% compute
options = sdpsettings('solver','mosek');
sol = optimize(constraints,objective,options)
time = sol.solvertime;

%  %% update
%  x0  =x_nom(:,i+1);
% end
t1 = cputime;
time = t1-t0;

for i = 1:N
u_nom(:,i) = value(u{i});      
u_e(i,:) = -K_1;
x_nom(:,i+1)   =  A*x_nom(:,i) + B*u_nom(:,i);
end
 %% real system



obj = 0;
for i =1:N
   obj   = obj + x_nom(:,i)'*Q*x_nom(:,i)+ u_nom(:,i)'*R*u_nom(:,i); 
end

   obj  = obj + x_nom(:,end)'*P*x_nom(:,end); 
    
figure(1)
hold on
plot(x_real(1,:),x_real(2,:),'b-o')
plot(x_real(1,end),x_real(2,end),'k-o','MarkerFaceColor','k');
obj = zeros(100,1);
for i = 1:100
    x_real=x0;
    obj(i,1)= x_real(:,1)'*Q*x_real(:,1);
    for h = 1:N
       w(:,h) = randn(2,1)*0.1;
       
       e_real(:,h+1)  = (A+B*u_e(h,:))*e_real(:,h) + w(:,h);
       
       x_real(:,h+1)  =  A*x_real(:,h) + B*(u_nom(:,h)+u_e(h,:)*e_real(:,h))+ w(:,h);
       
       obj(i,1) = obj(i,1)+ x_real(:,h+1)'*Q*x_real(:,h+1)+(u_nom(:,h)+u_e(h,:)*e_real(:,h))'*R*(u_nom(:,h)+u_e(h,:)*e_real(:,h));
    end
    plot(x_real(1,:),x_real(2,:),'b-o')
    plot(x_real(1,end),x_real(2,end),'k-o','MarkerFaceColor','g');
    
end
plot(x_nom(1,:),x_nom(2,:),'r-*')
legend('1','2','3')
axis( [-7 1 -2 4] ) 
plot(x_real(1,1),x_real(2,1),'r-o','MarkerFaceColor','r');
set(gca,'LineWidth',2)
set(gca,'fontsize',20,'fontname','Times New Roman');
for h = 2:N
error_ellipse( diag(diag(sigma_e{h})),x_nom(:,h),'conf',0.9974);
end
sum(obj)/100


figure(2)
hold on
for i = 1:100
    x_real=x0;
    for h = 1:N
       w(:,h) = randn(2,1)*0.1;
       e_real(:,h+1)  = (A+B*u_e(h,:))*e_real(:,h) + w(:,h);
       x_real(:,h+1)  =  A*x_real(:,h) + B*(u_nom(:,h)+u_e(h,:)*e_real(:,h))+ w(:,h);
       ue(i,h) = u_e(h,:)*e_real(:,h);
       ur(i,h) = u_nom(:,h)+u_e(h,:)*e_real(:,h);
    end
%     plot(1:10,ue,'b-o')
%     plot(10,ue(end),'o','MarkerFaceColor','g');
    
end
plot(1:N,u_nom(1,:),'r-*');
set(gca,'LineWidth',2)
set(gca,'fontsize',20,'fontname','Times New Roman');



%% ��ʼ��ͼ
figure (3)
%��������Ϊ���ݾ�����ɫ���á���Ƿ�
box_figure = boxplot(ue);
axis( [0 11 -1 1] ) 
%�����߿�
set(box_figure,'Linewidth',1.2);
boxobj = findobj(gca,'Tag','Box');
for i = 1:num
    patch(get(boxobj(i),'XData'),get(boxobj(i),'YData'),'b','FaceAlpha',0.5,...
        'LineWidth',1.1);
end
hold on;
set(gca,'LineWidth',2)
set(gca,'fontsize',20,'fontname','Times New Roman');


