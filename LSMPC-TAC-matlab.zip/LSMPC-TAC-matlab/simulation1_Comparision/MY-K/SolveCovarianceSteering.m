function [time,obj,Ksol,EXsol,Lsol] = SolveCovarianceSteering(PS)   
    %%% Lower Stage %%%
    N = PS.N;
    nx = PS.nx;
    nu = PS.nu;
    ScriptA = PS.ScriptA;
    ScriptB = PS.ScriptB;
    ScriptD = PS.ScriptD;
    ScriptE = PS.ScriptE;
    ScriptMuw = PS.ScriptMuw;

    % Define optimiz ation variables
    K = [];
    for i = 1:N+1
        K = [K;  sdpvar(nu,(i-1)*nx) zeros(nu,(N-i+2)*nx)];
    end
%     K = zeros(nu,(N+1)*nx));
%     for i = 1:N
%         K = [K;  sdpvar(nu,(i-1)*nx) zeros(nu,(N-i+2)*nx)];
%     end
    % Useful matrices
    SigmaY = ScriptE*PS.Sigma0*ScriptE'+ScriptD*eye(2*(N+1))*ScriptD';
    IplusBK = ScriptA^-1*(eye((N+1)*nx)+ScriptB*K);
    EN = [zeros(nx,(N)*nx) eye(nx)];
    S1 = computeS(SigmaY);
    S = S1;
    % System Dynamics
%     Scriptmuw =0;
    MuY = ScriptE * PS.mu0 + ScriptD*ScriptMuw;
    EX  = IplusBK*MuY;
    MuV = -K*MuY;
    SigmaV = K*SigmaY*K';
    Z = EN*IplusBK*S;
    % Define constraints
    Constraints = [];
    % Boundary condition
    Constraints = [Constraints, EN*EX == PS.muf];      
    Constraints = [Constraints, [PS.Sigmaf Z; Z' eye((N+1)*nx)] >= 0];
    % Chance Constraints
    Constraints = chanceConstraints(Constraints,EX,S,IplusBK,K,PS,MuV,SigmaV);
    % Objective Function
    Jmean = EX'*PS.Q*EX + V'*PS.R*V;
%     Jcov = trace((IplusBK'*PS.Q*IplusBK + K'*PS.R*K)*(SigmaY+MuY*MuY'));
    Objective =  Jcov;
%     Objective = Jcov;
    % Solve the Problem
    options = sdpsettings('solver','mosek');
    sol = optimize(Constraints,Objective,options)
    
    % Get performance measure values
    time = sol.solvertime;
    obj = value(Objective);
    % Get control values
%     Vsol  = reshape(value(V),nu,N+1);
    Ksol  = value(K);
    EXsol = reshape(value(EX),nx,N+1);
    LL    = clean(-(Ksol*ScriptB+eye((N+1)*nu))^-1*Ksol*ScriptA,10^-3);
    Lsol  = cell(N,1);
    for i = 1:N
        Lsol{i,1} = LL(i*nu+1:(i+1)*nu,(i-1)*nx+1:i*nx);
    end

end

function Constraints = chanceConstraints(Constraints,EX,S,IplusBK,K,PS,MuV,SigmaV)
    a_x = PS.alphax;
    a_u = PS.alphau;
    b_x = PS.betax;
    b_u = PS.betau;
    Ns = PS.Ns;
    Nc = PS.Nc;
    N = PS.N;
    deltax = PS.deltax;
    deltau = PS.deltau;
    nx = PS.nx;
    nu = PS.nu;
    
    % State chance constraints
    for k = 1:N
        Ek = [zeros(nx,k*nx) eye(nx) zeros(nx,(N-k)*nx)];
        for j = 1:Ns
            ICDFx = norminv(1-deltax(j,k));
            stateConstraint = a_x(:,j)' * Ek * EX + ICDFx * norm(S'*IplusBK'*Ek'*a_x(:,j)) <= b_x(j);
            Constraints = [Constraints,stateConstraint];
        end
    end

end