function b_r=Compute_max_terminal_set1(PS)
P=PS.P;
K_1=PS.K_1;
nv = size(K_1,1);
a_x = PS.alphax;
a_u = PS.alphau;
b_x = PS.betax;
b_u = PS.betau;
Ns = PS.Ns;
Nc = PS.Nc;
N = PS.N;
deltax = PS.deltax;
deltau = PS.deltau;
nx = 2;
nu = 2;
sigma_f = PS.Sigmaf;
umax = max(PS.betau);

% % %% ���ַ��� a set  Xf={x|x*P*x'<=b} satisfies a*Kx<= b for all x in  Xf
% obj1 = 10000;
% obj2 = 0;
% target = 10000;
% j =1000;
% while j>max(b_u) || j < max(b_u)-10^-6
% obj = 0;
% x = sdpvar(2,1);
% obj = K_1*x;
% con = [];
% con = [con,norm(P^0.5*x)<= target ];
% sol = optimize(con,-obj);
% j = value(obj);
% if j >= max(b_u)
%     obj1   = target;
%     target = (obj2+target)/2;
% else 
%     obj2 = target;
%     target = (obj1+target)/2;
% end
% end
% b =  target^2;
% 
% %% �����任 a set  Xf={x|x*P*x'<=b} satisfies a*Kx<= b for all x in  Xf

b1 = sdpvar(1);
obj = 0;
obj = obj+1/(b1*b1);
con = [];
w = sdpvar(nx,1);
u = sdpvar(nu,1);
con = [con ,w'*P*w<= 1, uncertain(w)];
con = [con,a_u'*K_1*w*b1<=b_u];
sol = optimize(con,obj)
b = value(b1^2);


%% 
% % %% �����任 a set  Xf={x|x*P*x'<=b} satisfies a*Kx<= b for all x in  Xf
% 
% b1 = sdpvar(1);
% obj = 0;
% obj = obj+1/(b1*b1);
% con = [];
% w = sdpvar(2,1);
% u = sdpvar(1,1);
% con = [con ,w'*P*w<= 1, uncertain(w)];
% 
% for j = 1:Ns
% ICDFx = norminv(1-deltax(j,end));
% J = a_x(j,:) * w + ICDFx * norm(sigma_f^0.5*a_x(j,:)')-b_x(j)/b1 ;
% con = [con ,J<=0];
% end
% 
% for j = 1:Nc
% ICDFx = norminv(1-deltax(j,end));
% J = a_u(j,:)*K_1 * w + ICDFx * norm(sigma_f^0.5*K_1'*a_u(j,:)')-b_u(j)/b1 ;
% con = [con ,J<=0];
% end
% 
% sol = optimize(con,obj)
% b = value(b1^2);


% b = 17;
%% ������ a set  Xf={x|x*P*x'<=b} satisfies input and state constraint for all x in  Xf

% state chance constraint
% Obj = ones(Ns,1);
% i = 0;
% while max(Obj)>0
% b = b-i*0.01;
% for j = 1:Ns
% con = [];
% x = sdpvar(nx,1);
% con = [con,x'*P*x<= b ];
% ICDFx = norminv(1-deltax(j,end));
% J = a_x(j,:) * x + ICDFx * norm(sigma_f^0.5*a_x(j,:)')-b_x(j) ;
% sol = optimize(con,-J);
% Obj(j) = value(J);
% end
% i = i+1;
% end

% input chance constraint

% Obj = ones(Nc,1);
% i = 0;
% while max(Obj)>0
% b = b-i*0.1;
% for j = 1:Nc
% con = [];
% x = sdpvar(2,1);
% con = [con,x'*P*x<= b ];
% ICDFx = norminv(1-deltax(j,end));
% J = a_u(j,:)*K_1 * x + ICDFx * norm(sigma_f^0.5*K_1'*a_u(j,:)')-b_u(j) ;
% % J = a_u(j,:)*K_1 * x -b_u(j) ;
% sol = optimize(con,-J);
% Obj(j) = value(J);
% end
% i = i+1;
% end




b_r = value(b)
end

% b=sdpvar(1);
% u =  sdpvar(1);
% P =[ 1141    93.9;
%     93.9    146.3];
% K_1 =[-6.2045   -7.9569];
% a_u =[     1;
%     -1];
% b_u =[3;
%      3];
% con = [];
% w = sdpvar(2,1);
% u = K_1*w;
% con = [con,b>=0 ];
% con = [con,a_u * u <=b_u,norm(P^0.5*w)<=b, uncertain(w) ];
% obj = 0;
% obj = obj+u ;
% sol = optimize(con,obj)
% % 
% % % 
% b = 17;
% u =  sdpvar(1);
% % P =[  128.6131   24.4290
% %    24.4290   32.1638];
% % K_1 =-[    2.6125    4.0995];
% a_u =[     1;
%     -1];
% b_u =[     3;
%      3];
% con = [];
% w = sdpvar(2,1);
% u = K_1*w;
% con = [con,norm(P^0.5*w)<=b];
% obj = 0;
% obj = obj+u ;
% sol = optimize(con,obj)
% value(obj)


% y = sdpvar (2,1)
% con = [];
% con = [con ,y'*P*y<= b^2];
% sol = optimize(con,-K_1*y)
% value(K_1*y)
